<!DOCTYPE html>
<html lang="en">

<head>
    @include("layouts/head")
    <title>Document</title>
</head>

<body>
@include("layouts/navbar")
<h1>Home Page</h1>
<a href="/about">Go to About page</a>
</body>

</html>