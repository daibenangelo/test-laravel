<!DOCTYPE html>
<html lang="en">

<head>
    @include("layouts/head")
    <title>Document</title>
</head>

<body>
@include("layouts/navbar")
<h1>View Shop</h1>
<p>Currently viewing page {{$id}}</p>
</body>

</html>