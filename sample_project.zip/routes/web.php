<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\StudentsController;
use App\Http\Controllers\FacultiesController;

Route::get('/', function () {
    return view('index');
});

Route::get('/about', function () {
    return view('about');
});

Route::get('/shop/{id?}', [ShopController::class, 'show']);
Route::get('/admin/students', [StudentsController::class, 'index']);

Route::resource('/admin/faculties', FacultiesController::class);

Route::get('/admin/students/{id}/upload', [StudentsController::class, 'showUpload']);
Route::post('/admin/students/{id}/upload', [StudentsController::class, 'upload']);
?>