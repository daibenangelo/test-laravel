<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>ISCP Restaurant - Cart</title>
</head>
<body>
    <form action="/restaurant/checkout" method="POST">
        <?php echo csrf_field(); ?>
        <h1>Total order is ₱<?php echo e($total); ?></h1>
        <ul>
            <?php for($i = 0; $i < count($products); $i++): ?>
                <?php if($request -> input('order_' . $products[$i] -> product_id) > 0): ?>
                    <li><?php echo e($products[$i] -> name); ?>: <?php echo e($request -> input('order_' . $products[$i] -> product_id)); ?></li>
                <?php endif; ?>
                <input
                name="order_<?php echo e($products[$i]->product_id); ?>"
                value="<?php echo e($request -> input('order_' . $products[$i] -> product_id)); ?>"
                hidden
                />
            <?php endfor; ?>
            <button type="submit">Place order</button>
        </ul>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/restaurant_cart.blade.php ENDPATH**/ ?>