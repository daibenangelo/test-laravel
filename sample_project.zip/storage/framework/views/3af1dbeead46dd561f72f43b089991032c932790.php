<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Student Finder</title>
</head>
<body>
    <h1>Student Finder</h1>
    <form action="/student_finder" method="POST">
        <?php echo csrf_field(); ?>
        <label>First name:</label>
        <input type="text" name="fname"></input>
        <label>Last name:</label>
        <input type="text" name="lname"></input>
        <button type="submit">Submit</button>
    </form>
    
    <?php if($students != ""): ?>
        <?php if(count($students) != 0): ?>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul>
                    <li><?php echo e($student -> last_name); ?>, <?php echo e($student -> first_name); ?></li>
                    <li><?php echo e($student -> date_enrolled); ?></li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>No student with that name found!</p>
        <?php endif; ?>
    <?php else: ?>
        <p>Please enter a first name and last name!</p>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/student_finder.blade.php ENDPATH**/ ?>