<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(count($faculty) > 0): ?>
    <?php $__currentLoopData = $faculty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1><?php echo e($f->last_name); ?>, <?php echo e($f->first_name); ?> Info</h1>
    <ul>
        <li>First name: <?php echo e($f->first_name); ?></li>
        <li>Last name: <?php echo e($f->last_name); ?></li>
        <li>Birthdate: <?php echo e($f->birthdate); ?></li>
        <li>Gender: <?php echo e($f->gender); ?></li>
        <li>Mobile number: <?php echo e($f->mobile_number); ?></li>
        <li>Email address: <?php echo e($f->email_address); ?></li>
        <li>Date entered: <?php echo e($f->date_entered); ?></li>
        <li>Postion: <?php echo e($f->position); ?></li>
        <li>Department: <?php echo e($f->department); ?></li>
    </ul>
    <h2>Academic Background</h2>
    <table class="table">
        <tr>
            <th>Undergraduate</th>
            <td><?php echo e($f->unders_enrolled); ?></td>
            <td><?php echo e($f->unders_year_received); ?></td>
        <tr>
        <?php if($f->has_masters): ?>
        <tr>
            <th>Masters</th>
            <td><?php echo e($f->masters_enrolled); ?></td>
            <td><?php echo e($f->masters_year_received); ?></td>
        <tr>
        <?php endif; ?>
        <?php if($f->has_doctors): ?>
        <tr>
            <th>Doctorate</th>
            <td><?php echo e($f->doctors_enrolled); ?></td>
            <td><?php echo e($f->doctors_year_received); ?></td>
        <tr>
        <?php endif; ?>
    </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<p>Nothing here. <a href="/">Go back to Home page.</a></p>
<?php endif; ?>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/faculties_show.blade.php ENDPATH**/ ?>