<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Admin Login</title>
</head>
<body>
    <?php if(Session::has('success')): ?>
        <p style="color:green"><?php echo e(Session::get('success')); ?></p>
    <?php endif; ?>
    <?php if(Session::has('fail')): ?>
        <p style="color:red"><?php echo e(Session::get('fail')); ?></p>
    <?php endif; ?>
    <h1>Admin Login</h1>
    <form action="/admin" method="POST">
        <?php echo csrf_field(); ?>
        <label>Email:</label>
        <input type="email" name="email"></input><br>
        <label>Password:</label>
        <input type="password" name="pw"></input><br>
        <button type="submit">Login</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/admin_login.blade.php ENDPATH**/ ?>