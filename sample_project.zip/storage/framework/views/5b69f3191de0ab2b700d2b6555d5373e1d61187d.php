<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>Faculties</title>
</head>
<body>
    <?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Faculties</h1>
    <a href="students">Go to students</a>
    <table class="table">
        <tr>
            <th>Faculty ID</th>
            <th>Name</th>
            <th>Academe Points</th>
        </tr>
        <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($faculty -> faculty_id); ?></td>
            <td><?php echo e($faculty -> last_name); ?>, <?php echo e($faculty -> first_name); ?></td>
            <td><?php echo e($faculty -> academe_points); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/faculties.blade.php ENDPATH**/ ?>