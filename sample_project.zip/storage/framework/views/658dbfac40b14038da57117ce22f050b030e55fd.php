<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Upload Student Photo</title>
</head>
<body>
    <h1>Upload Student Photo</h1>
    <form action="/students/upload/<?php echo e(request() -> route('id')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!-- <label>Student ID:</label>
        <input type="number" name="student_id"></input><br> -->
        <label>Upload photo:</label>
        <input type="file" name="image"></input>
        <button type="submit">Submit</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/students_upload.blade.php ENDPATH**/ ?>