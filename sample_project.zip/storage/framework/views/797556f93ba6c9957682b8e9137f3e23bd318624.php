<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Register</title>
</head>
<body>
    <p style="color:red">
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </p>
    <h1>Register</h1>
    <form action="/register" method="POST">
        <?php echo csrf_field(); ?>
        <label>First name:</label>
        <input type="text" name="fname"></input><br>
        <label>Last name:</label>
        <input type="text" name="lname"></input><br>
        <label>Email:</label>
        <input type="email" name="email"></input><br>
        <label>Password (must have 1 lowercase letter, 1 uppercase letter, 1 number, 1 symbol):</label>
        <input type="password" name="pw"></input><br>
        <label>Confirm Password:</label>
        <input type="password" name="conpw"></input><br>
        <button type="submit">Submit</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/register.blade.php ENDPATH**/ ?>