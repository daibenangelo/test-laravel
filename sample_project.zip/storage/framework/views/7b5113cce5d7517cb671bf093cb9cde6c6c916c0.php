<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Profile Edit</title>
</head>
<body>
    <h1>Profile Edit</h1>
    <form action="/profile/edit" method="POST">
        <?php echo csrf_field(); ?>
        <label>Mobile number</label>
        <input type="text" name="mobile"></input>
        <label>Emaill address</label>
        <input type="email" name="email"></input>
        <button type="submit">Save</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/profile_edit.blade.php ENDPATH**/ ?>