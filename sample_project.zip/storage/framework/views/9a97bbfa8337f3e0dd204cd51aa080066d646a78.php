<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Edit Class</title>
</head>
<body>
    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1>Edit class <?php echo e($class -> class_id); ?></h1>
    <form action="/classes/<?php echo e($class -> class_id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label>Room</label>
        <input type="text" name="room" value="<?php echo e($class -> room); ?>"></input><br>
        <label>Schedule</label>
        <input type="text" name="schedule" value="<?php echo e($class -> schedule); ?>"></input><br>
        <label>Subject ID</label>
        <input type="number" name="subject_id" value="<?php echo e($class -> subject_id); ?>"></input><br>
        <button type="submit">Submit</button>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/classes_edit.blade.php ENDPATH**/ ?>