<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>ISCP Restaurant</title>
</head>
<body>
    <h1>Restaurant Menu</h1>
    <form action="/restaurant" method="POST">
        <?php echo csrf_field(); ?>
        <table class="table">
            <tr>
                <th>Name</th>
                <th>Price</th>
                <th>Order</th>
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product -> name); ?></td>
                <td>₱<?php echo e($product -> price); ?></td>
                <td><input type="number" name="order_<?php echo e($product -> product_id); ?>" value="0"></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <button type="submit">Submit</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/restaurant.blade.php ENDPATH**/ ?>