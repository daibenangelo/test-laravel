<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>

<body>
    <?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Upload Photo</h1>
    <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>Uploading photo for <?php echo e($s->last_name); ?>, <?php echo e($s-> first_name); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <form action="/admin/students/<?php echo e(request() -> route('id')); ?>/upload" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label>Upload photo:</label>
        <input type="file" name="image"></input><br>
        <button type="submit">Submit</button>
    </form>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\Bootcamp\bootcamp\sample_project\resources\views/students_upload.blade.php ENDPATH**/ ?>