<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>ISCP</h1>
    <img src="/img/iscp.png" alt="ISCP logo" width="100px"/>
    <p>Hello <?php echo e($name); ?>,</p>
    <p><?php echo e($body); ?></p>
    <p>Best regards, <br>The ISCP Admin</p>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/emails/email_student.blade.php ENDPATH**/ ?>