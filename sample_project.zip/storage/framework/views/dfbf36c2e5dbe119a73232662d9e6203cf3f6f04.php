<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Enrollment</title>
</head>
<body>
    <h1>Student Enrollment</h1>
    <form action="/student_enrollment" method="POST">
        <?php echo csrf_field(); ?>
        <label>Student ID:</label>
        <input type="number" name="student_id"></input><br>
        <label>Subjects:</label>
        <select name="subject">
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($subject -> subject_id); ?>"><?php echo e($subject -> name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit">Submit</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/student_enrollment.blade.php ENDPATH**/ ?>