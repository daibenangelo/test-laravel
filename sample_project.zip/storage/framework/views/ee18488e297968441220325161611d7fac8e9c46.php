<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>New Class</title>
</head>
<body>
    <h1>New class</h1>
    <form action="/classes" method="POST">
        <?php echo csrf_field(); ?>
        <label>Room</label>
        <input type="text" name="room"></input><br>
        <label>Schedule</label>
        <input type="text" name="schedule"></input><br>
        <label>Subject ID</label>
        <input type="number" name="subject_id"></input><br>
        <button type="submit">Submit</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/class_create.blade.php ENDPATH**/ ?>