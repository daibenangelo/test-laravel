<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
    <style>
        .chart1{
            border: 5px dotted;
        }
    </style>
</head>
<body>
    <h1>Admin Dashboard</h1>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <?php echo $chart1->renderHtml(); ?>

            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
            <?php echo $chart2->renderHtml(); ?>

            </div>
        </div>
    </div>
</body>
<?php echo $__env->yieldContent('javascript'); ?>
    <?php echo $chart1->renderChartJsLibrary(); ?>

    <?php echo $chart1->renderJs(); ?>

    <?php echo $chart2->renderChartJsLibrary(); ?>

    <?php echo $chart2->renderJs(); ?>

</html><?php /**PATH C:\Users\Daiben\Desktop\bootcamp\test\resources\views/admin_dashboard.blade.php ENDPATH**/ ?>